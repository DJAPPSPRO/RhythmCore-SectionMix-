# RhythmCore SectionMix — Native Android

A **native Kotlin Android Studio project**, not a WebView wrapper.

## Build
1. Open this folder in Android Studio (Ladybug or newer).
2. Install Android SDK Platform 35 and JDK 17 if prompted.
3. Allow Gradle to sync. Select **Build > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android device and install it.

## Usage
- **+ Song:** import an audio file using Android's system picker; access persists across app restarts.
- Enter the **correct BPM** and tap **Apply**. BPM is not auto-detected.
- Tap **Set 1st Beat**, then tap the waveform where beat one begins.
- Tap a white 8-beat boundary to choose a section, then **Add 8 Beats ↓**.
- Load another song and continue adding sections. The lower timeline keeps the previous clips.
- Tap a timeline clip, use **Move** buttons to rearrange, or **Delete**.
- **Play Mix** previews the assembled clips in order. **Export WAV** saves the arrangement.
- Projects are saved locally automatically; original audio files are never modified.

## Current limitations
- Fixed-BPM grid only; songs with live tempo drift need manual anchor-based beatgrid support in a future version.
- Source playback and mix playback use MediaPlayer with clip-to-clip gaps; it is **not sample-accurate or gapless**.
- Export concatenates decoded PCM with no beat matching, tempo stretching, crossfades, or resampling. WAV export requires **identical sample rates and channel counts** across all imported clips. Some codecs/devices may not output PCM 16-bit and will fail gracefully.
- Tap-based selection and move buttons are provided; direct clip dragging and pinch zoom are not yet implemented.
- Only one project is saved locally. Imported URI permissions must remain valid.
- Export of long tracks can be slow. Waveform generation runs in a background thread.

This repository is provided as source code. An APK was **not compiled or tested** in the creation environment because Android SDK/Gradle were unavailable.
