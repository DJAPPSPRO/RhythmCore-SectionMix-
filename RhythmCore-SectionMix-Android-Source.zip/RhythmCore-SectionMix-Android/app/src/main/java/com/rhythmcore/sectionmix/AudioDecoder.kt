package com.rhythmcore.sectionmix

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.OutputStream
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

/** Android MediaCodec PCM decoder. Expects 16-bit interleaved PCM output for WAV export. */
object AudioDecoder {
    data class Info(val sampleRate: Int, val channels: Int, val durationUs: Long)
    fun inspect(context: Context, uri: Uri): Info {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            val idx = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true } ?: error("No audio track")
            val f = ex.getTrackFormat(idx)
            return Info(f.getInteger(MediaFormat.KEY_SAMPLE_RATE), f.getInteger(MediaFormat.KEY_CHANNEL_COUNT), f.getLong(MediaFormat.KEY_DURATION))
        } finally { ex.release() }
    }
    fun decode(context: Context, uri: Uri, startUs: Long = 0, endUs: Long = Long.MAX_VALUE, consume: (ByteArray, Int, Int) -> Unit) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(context, uri, null)
            val idx = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true } ?: error("No audio track")
            ex.selectTrack(idx)
            val format = ex.getTrackFormat(idx)
            codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(format, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                if (!inputDone) {
                    val inputId = codec.dequeueInputBuffer(10000)
                    if (inputId >= 0) {
                        val input = codec.getInputBuffer(inputId)!!
                        input.clear()
                        val size = ex.readSampleData(input, 0)
                        if (size < 0) { codec.queueInputBuffer(inputId, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                        else { codec.queueInputBuffer(inputId, 0, size, ex.sampleTime, 0); ex.advance() }
                    }
                }
                when (val outputId = codec.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = codec.outputFormat
                        if (out.containsKey(MediaFormat.KEY_PCM_ENCODING) && out.getInteger(MediaFormat.KEY_PCM_ENCODING) != 2) error("Audio format is not PCM 16-bit")
                    }
                    else -> if (outputId >= 0) {
                        if (info.size > 0) {
                            val output = codec.getOutputBuffer(outputId)!!
                            output.position(info.offset); output.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size); output.get(bytes)
                            val out = codec.outputFormat
                            val rate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            val channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            val frameSize = channels * 2
                            val frames = bytes.size / frameSize
                            val firstFrame = max(0L, ((startUs - info.presentationTimeUs) * rate / 1_000_000L)).coerceAtMost(frames.toLong()).toInt()
                            val lastFrame = ((endUs - info.presentationTimeUs) * rate / 1_000_000L).coerceIn(0L, frames.toLong()).toInt()
                            if (lastFrame > firstFrame) consume(bytes.copyOfRange(firstFrame * frameSize, lastFrame * frameSize), rate, channels)
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0 || info.presentationTimeUs > endUs
                        codec.releaseOutputBuffer(outputId, false)
                    }
                }
            }
        } finally { try { codec?.stop() } catch (_: Exception) {}; codec?.release(); ex.release() }
    }
    fun buildPeaks(context: Context, uri: Uri, durationUs: Long, count: Int = 1600): FloatArray {
        val peaks = FloatArray(count)
        var frameOffset = 0L
        decode(context, uri) { data, rate, channels ->
            val frames = data.size / (channels * 2)
            for (f in 0 until frames) {
                val pos = ((frameOffset + f).toDouble() / (durationUs.toDouble() * rate / 1_000_000.0) * count).toInt().coerceIn(0, count - 1)
                var peak = 0
                for (ch in 0 until channels) {
                    val i = (f * channels + ch) * 2
                    val sample = (data[i].toInt() and 255) or (data[i + 1].toInt() shl 8)
                    peak = max(peak, abs(sample.toShort().toInt()))
                }
                peaks[pos] = max(peaks[pos], peak / 32768f)
            }
            frameOffset += frames
        }
        return peaks
    }
    fun writeWavHeader(out: OutputStream, dataSize: Long, rate: Int, channels: Int) {
        fun ascii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
        fun le32(n: Long) { repeat(4) { out.write(((n ushr (8 * it)) and 255).toInt()) } }
        fun le16(n: Int) { out.write(n and 255); out.write((n ushr 8) and 255) }
        ascii("RIFF"); le32(36 + dataSize); ascii("WAVEfmt "); le32(16); le16(1)
        le16(channels); le32(rate.toLong()); le32(rate.toLong() * channels * 2); le16(channels * 2); le16(16)
        ascii("data"); le32(dataSize)
    }
}
