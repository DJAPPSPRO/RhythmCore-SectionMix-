package com.rhythmcore.sectionmix

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    data class Song(val uri: String, val title: String, val durationMs: Long, var bpm: Double = 120.0, var firstMs: Long = 0, var peaks: FloatArray = floatArrayOf())
    data class Clip(val songUri: String, val startMs: Long, val endMs: Long)
    private val songs = linkedMapOf<String, Song>()
    private val clips = mutableListOf<Clip>()
    private var current: Song? = null
    private var selectedSection = 0
    private var selectedClip = -1
    private var zoom = 1f
    private var player: MediaPlayer? = null
    private var playbackQueue = -1
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var source: WaveView
    private lateinit var timeline: WaveView
    private lateinit var status: TextView
    private lateinit var bpm: EditText
    private lateinit var first: TextView
    private lateinit var clipLabel: TextView
    private var firstBeatMode = false
    private var playheadMs = 0L
    private val tick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && p.isPlaying) {
                if (playbackQueue >= 0) {
                    val c = clips.getOrNull(playbackQueue)
                    if (c != null && p.currentPosition >= c.endMs - 15) playNextClip()
                } else { playheadMs = p.currentPosition.toLong(); source.invalidate() }
            }
            handler.postDelayed(this, 40)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15, 16, 20)); setPadding(12, 12, 12, 8) }
        fun title(t: String) = TextView(this).apply { text = t; textSize = 18f; setTextColor(Color.WHITE); setPadding(3, 7, 3, 7) }
        fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun btn(t: String, action: () -> Unit) = Button(this).apply { text = t; textSize = 11f; setAllCaps(false); setOnClickListener { action() } }
        root.addView(title("RHYTHMCORE  /  SECTIONMIX"))
        val top = row()
        top.addView(btn("+ Song") { pickSong() }, LinearLayout.LayoutParams(0, 52, 1f))
        top.addView(btn("Set 1st Beat") { firstBeatMode = true; show("Tap the first beat on the top waveform") }, LinearLayout.LayoutParams(0, 52, 1f))
        top.addView(btn("Play / Stop") { if (player?.isPlaying == true) stopPlayback() else playSource() }, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(top)
        val controls = row()
        controls.addView(title("BPM"))
        bpm = EditText(this).apply { setText("120"); inputType = 8194; setSingleLine(true); setTextColor(Color.WHITE); textSize = 16f }
        controls.addView(bpm, LinearLayout.LayoutParams(0, 55, 1f))
        controls.addView(btn("Apply") { applyBpm() })
        first = title("First: 0.00s")
        controls.addView(first)
        root.addView(controls)
        root.addView(title("SOURCE SONG  •  tap an 8-beat block"))
        source = WaveView(false)
        root.addView(source, LinearLayout.LayoutParams(-1, 0, 1f))
        val editRow = row()
        editRow.addView(btn("− Zoom") { zoom = max(1f, zoom / 1.5f); refresh() }, LinearLayout.LayoutParams(0, 48, 1f))
        editRow.addView(btn("+ Zoom") { zoom = min(32f, zoom * 1.5f); refresh() }, LinearLayout.LayoutParams(0, 48, 1f))
        editRow.addView(btn("Add 8 Beats ↓") { addSection() }, LinearLayout.LayoutParams(0, 48, 2f))
        root.addView(editRow)
        root.addView(title("MASHUP TIMELINE  •  clips remain when songs change"))
        timeline = WaveView(true)
        root.addView(timeline, LinearLayout.LayoutParams(-1, 0, 0.75f))
        clipLabel = title("No clips yet")
        root.addView(clipLabel)
        val arrange = row()
        arrange.addView(btn("◀ Move") { moveClip(-1) }, LinearLayout.LayoutParams(0, 48, 1f))
        arrange.addView(btn("Move ▶") { moveClip(1) }, LinearLayout.LayoutParams(0, 48, 1f))
        arrange.addView(btn("Delete") { if (selectedClip in clips.indices) { clips.removeAt(selectedClip); selectedClip = -1; save(); refresh() } }, LinearLayout.LayoutParams(0, 48, 1f))
        arrange.addView(btn("Play Mix") { playMix() }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(arrange)
        val bottom = row()
        bottom.addView(btn("Save Project") { save(); show("Project saved") }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(btn("Export WAV") { exportWav() }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(bottom)
        status = TextView(this).apply { textSize = 12f; setTextColor(Color.LTGRAY); text = "Load a song to begin"; setPadding(4, 5, 4, 5) }
        root.addView(status)
        setContentView(root)
        restore()
        handler.post(tick)
    }
    private fun show(s: String) { status.text = s }
    private fun pickSong() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        startActivityForResult(i, 10)
    }
    @Deprecated("Activity result API for minimal dependency-free example")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 10) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val key = uri.toString()
            val info = try { AudioDecoder.inspect(this, uri) } catch (e: Exception) { show("Cannot read song: ${e.message}"); return }
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Song"
            val song = songs[key] ?: Song(key, name, info.durationUs / 1000)
            songs[key] = song
            current = song; bpm.setText("%.2f".format(java.util.Locale.US, song.bpm)); first.text = "First: %.2fs".format(java.util.Locale.US, song.firstMs / 1000.0)
            selectedSection = 0; playheadMs = 0; save(); refresh(); show("Loaded $name — ${clips.size} clips preserved")
            if (song.peaks.isEmpty()) thread {
                try { val peaks = AudioDecoder.buildPeaks(this, uri, info.durationUs); runOnUiThread { song.peaks = peaks; refresh() } }
                catch (e: Exception) { runOnUiThread { show("Waveform unavailable: ${e.message}") } }
            }
        } else if (requestCode == 11) data?.data?.let { writeWav(it) }
    }
    private fun applyBpm() {
        val value = bpm.text.toString().toDoubleOrNull()
        if (value == null || value < 30 || value > 300) { show("Enter BPM from 30 to 300"); return }
        current?.bpm = value; save(); refresh(); show("Grid updated to $value BPM")
    }
    private fun sectionMs(s: Song) = 480000.0 / s.bpm
    private fun addSection() {
        applyBpm()
        val s = current ?: return
        val a = (s.firstMs + selectedSection * sectionMs(s)).toLong().coerceAtLeast(0)
        val b = min(s.durationMs, (s.firstMs + (selectedSection + 1) * sectionMs(s)).toLong())
        if (b <= a) { show("Section is outside the song"); return }
        clips.add(Clip(s.uri, a, b)); selectedClip = clips.lastIndex; selectedSection++
        save(); refresh(); show("Added clip ${clips.size}: ${s.title}")
    }
    private fun moveClip(delta: Int) {
        val i = selectedClip; val j = i + delta
        if (i !in clips.indices || j !in clips.indices) return
        val c = clips.removeAt(i); clips.add(j, c); selectedClip = j; save(); refresh()
    }
    private fun refresh() {
        if (::source.isInitialized) source.invalidate()
        if (::timeline.isInitialized) timeline.invalidate()
        if (::clipLabel.isInitialized) {
            val total = clips.sumOf { it.endMs - it.startMs }
            clipLabel.text = "${clips.size} clips  •  ${"%.1f".format(total / 1000.0)} sec  •  selected: ${if (selectedClip >= 0) selectedClip + 1 else "none"}"
        }
    }
    private fun stopPlayback() { playbackQueue = -1; player?.release(); player = null; refresh() }
    private fun playSource() {
        val s = current ?: return
        stopPlayback()
        try { player = MediaPlayer().apply { setDataSource(this@MainActivity, Uri.parse(s.uri)); prepare(); seekTo(playheadMs.toInt()); start() }; show("Playing ${s.title}") }
        catch (e: Exception) { show("Playback failed: ${e.message}") }
    }
    private fun playMix() {
        if (clips.isEmpty()) { show("Add clips first"); return }
        stopPlayback(); playbackQueue = 0; startClip()
    }
    private fun startClip() {
        val c = clips.getOrNull(playbackQueue) ?: run { stopPlayback(); show("Mix finished"); return }
        player?.release()
        try { player = MediaPlayer().apply { setDataSource(this@MainActivity, Uri.parse(c.songUri)); prepare(); seekTo(c.startMs.toInt()); start() }; refresh() }
        catch (e: Exception) { stopPlayback(); show("Cannot play clip: ${e.message}") }
    }
    private fun playNextClip() { playbackQueue++; startClip() }
    private fun save() {
        val root = JSONObject(); val ss = JSONArray(); val cc = JSONArray()
        songs.values.forEach { ss.put(JSONObject().put("uri", it.uri).put("title", it.title).put("duration", it.durationMs).put("bpm", it.bpm).put("first", it.firstMs)) }
        clips.forEach { cc.put(JSONObject().put("uri", it.songUri).put("start", it.startMs).put("end", it.endMs)) }
        root.put("songs", ss).put("clips", cc).put("current", current?.uri ?: "")
        File(filesDir, "project.json").writeText(root.toString())
    }
    private fun restore() {
        try {
            val f = File(filesDir, "project.json"); if (!f.exists()) return
            val root = JSONObject(f.readText()); val ss = root.getJSONArray("songs")
            for (i in 0 until ss.length()) { val s = ss.getJSONObject(i); val song = Song(s.getString("uri"), s.getString("title"), s.getLong("duration"), s.getDouble("bpm"), s.getLong("first")); songs[song.uri] = song }
            val cc = root.getJSONArray("clips")
            for (i in 0 until cc.length()) { val c = cc.getJSONObject(i); clips.add(Clip(c.getString("uri"), c.getLong("start"), c.getLong("end"))) }
            current = songs[root.optString("current")]
            current?.let { bpm.setText("${it.bpm}"); first.text = "First: %.2fs".format(it.firstMs / 1000.0) }
            refresh(); show("Restored ${clips.size} clips")
            current?.let { s -> thread { try { val p = AudioDecoder.buildPeaks(this, Uri.parse(s.uri), s.durationMs * 1000); runOnUiThread { s.peaks = p; refresh() } } catch (_: Exception) {} } }
        } catch (e: Exception) { show("Restore failed: ${e.message}") }
    }
    private fun exportWav() {
        if (clips.isEmpty()) { show("Add clips before exporting"); return }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type = "audio/wav"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_TITLE, "SectionMix.wav") }
        startActivityForResult(i, 11)
    }
    private fun writeWav(uri: Uri) {
        show("Exporting WAV…")
        val snapshot = clips.toList()
        thread {
            try {
                val formats = snapshot.map { AudioDecoder.inspect(this, Uri.parse(it.songUri)) }
                val format = formats.first()
                require(formats.all { it.sampleRate == format.sampleRate && it.channels == format.channels }) { "WAV export requires matching sample rates and channel counts. Convert songs to the same format first." }
                val tmp = File(cacheDir, "sectionmix-export.wav")
                var bytesWritten = 0L
                FileOutputStream(tmp).use { out ->
                    AudioDecoder.writeWavHeader(out, 0, format.sampleRate, format.channels)
                    snapshot.forEach { c -> AudioDecoder.decode(this, Uri.parse(c.songUri), c.startMs * 1000, c.endMs * 1000) { data, _, _ -> out.write(data); bytesWritten += data.size } }
                }
                RandomAccessFile(tmp, "rw").use { raf -> raf.seek(4); repeat(4) { raf.write(((bytesWritten + 36) ushr (it * 8)).toInt() and 255) }; raf.seek(40); repeat(4) { raf.write((bytesWritten ushr (it * 8)).toInt() and 255) } }
                contentResolver.openOutputStream(uri)?.use { out -> tmp.inputStream().use { it.copyTo(out) } } ?: error("Cannot open output")
                tmp.delete()
                runOnUiThread { show("WAV exported successfully") }
            } catch (e: Exception) { runOnUiThread { show("Export failed: ${e.message}") } }
        }
    }
    inner class WaveView(private val isTimeline: Boolean) : View(this) {
        private val p = Paint(3)
        private val bg = Color.rgb(24, 27, 34)
        init { setBackgroundColor(bg) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (isTimeline) {
                val total = clips.sumOf { it.endMs - it.startMs }.coerceAtLeast(1)
                var x = 0f
                clips.forEachIndexed { i, c ->
                    val cw = w * (c.endMs - c.startMs).toFloat() / total
                    p.color = if (i == selectedClip) Color.rgb(255, 191, 55) else if (i % 2 == 0) Color.rgb(55, 153, 197) else Color.rgb(71, 117, 163)
                    canvas.drawRect(x + 1, 15f, x + cw - 2, h - 15f, p)
                    p.color = Color.WHITE; p.textSize = 25f
                    canvas.drawText("${i + 1}", x + 9, h / 2, p)
                    x += cw
                }
            } else {
                val s = current ?: return
                val visibleMs = s.durationMs / zoom
                val maxStart = (s.durationMs - visibleMs).coerceAtLeast(0f)
                val start = (playheadMs - visibleMs / 2).coerceIn(0f, maxStart)
                val peaks = s.peaks
                p.strokeWidth = 2f; p.color = Color.rgb(57, 196, 217)
                for (i in 0 until width step 2) {
                    val t = start + (i / w) * visibleMs
                    val index = (t / s.durationMs * peaks.size).toInt().coerceIn(0, max(0, peaks.size - 1))
                    val amp = if (peaks.isEmpty()) 0.08f else peaks[index].coerceAtLeast(0.04f)
                    canvas.drawLine(i.toFloat(), h / 2 - amp * h * .44f, i.toFloat(), h / 2 + amp * h * .44f, p)
                }
                val step = sectionMs(s)
                val from = max(0, ((start - s.firstMs) / step).toInt() - 1)
                val to = min(200000, ((start + visibleMs - s.firstMs) / step).toInt() + 2)
                for (i in from..to) {
                    val x = ((s.firstMs + i * step - start) / visibleMs * w).toFloat()
                    if (x < 0 || x > w) continue
                    p.color = if (i == selectedSection) Color.YELLOW else Color.argb(190, 255, 255, 255)
                    p.strokeWidth = if (i == selectedSection) 4f else 1.5f
                    canvas.drawLine(x, 0f, x, h, p)
                }
                val px = ((playheadMs - start) / visibleMs * w).toFloat()
                p.color = Color.RED; p.strokeWidth = 3f; canvas.drawLine(px, 0f, px, h, p)
                p.color = Color.WHITE; p.textSize = 23f
                canvas.drawText(s.title.take(35), 12f, 29f, p)
            }
        }
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_DOWN) return true
            val x = (event.x / width).coerceIn(0f, 1f)
            if (isTimeline) {
                val total = clips.sumOf { it.endMs - it.startMs }.coerceAtLeast(1)
                var cursor = 0L
                selectedClip = clips.indexOfFirst { cursor += it.endMs - it.startMs; x * total < cursor }
            } else {
                val s = current ?: return true
                val visible = s.durationMs / zoom
                val start = (playheadMs - visible / 2).coerceIn(0f, (s.durationMs - visible).coerceAtLeast(0f))
                val tapped = (start + x * visible).toLong().coerceIn(0, s.durationMs)
                if (firstBeatMode) { s.firstMs = tapped; firstBeatMode = false; first.text = "First: %.2fs".format(tapped / 1000.0); show("First beat placed at ${tapped / 1000.0}s"); save() }
                else { playheadMs = tapped; selectedSection = max(0, ((tapped - s.firstMs) / sectionMs(s)).toInt()); player?.let { if (playbackQueue < 0) it.seekTo(tapped.toInt()) } }
            }
            refresh(); return true
        }
    }
    override fun onDestroy() { handler.removeCallbacks(tick); stopPlayback(); super.onDestroy() }
}
